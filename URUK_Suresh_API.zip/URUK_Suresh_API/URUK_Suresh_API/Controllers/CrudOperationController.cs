﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using URUK_Suresh_API;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace URUK_Suresh_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CrudOperationController : ControllerBase
    {
        Services.Services service;
        // GET: api/<CrudOperationController>
        [HttpGet]
        public void Get()
        {
            // return new string[] { "value1", "value2" };

            service.GetProducts();

            //return 
        }

        // GET api/<CrudOperationController>/5
        //[HttpGet("{id}")]
        //public string Get(int id)
        //{
        //    //return "value";
        //}

        // POST api/<CrudOperationController>
        [HttpPost]
        public void Post([FromBody] string value)
        {
            service.PostProducts(value);
        }

        // PUT api/<CrudOperationController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string Name,string desc)
        {
            service.UpDateProducts(Name, desc);
        }

        // DELETE api/<CrudOperationController>/5
        [HttpDelete("{id}")]
        public void Delete(string id)
        {
            service.DeleteProducts(id);
        }
    }
}
