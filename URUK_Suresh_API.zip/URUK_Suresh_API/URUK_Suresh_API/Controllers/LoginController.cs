﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using URUK_Suresh_API;
//using Services.;
namespace URUK_Suresh_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        
        Services.Services service;
        [HttpGet]
        public void GetLogin(string User_Name, string Password)
        {
            // Services.getLogin(User_Name, Password);
            service.getLogin(User_Name, Password);
            

        }
    }
}
