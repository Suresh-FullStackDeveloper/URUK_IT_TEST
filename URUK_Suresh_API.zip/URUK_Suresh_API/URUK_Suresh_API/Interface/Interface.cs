﻿namespace URUK_Suresh_API.Interface
{
    public interface Interface
    {

    }
}
