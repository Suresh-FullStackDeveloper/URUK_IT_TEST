﻿using Microsoft.Data.Sqlite;

namespace URUK_Suresh_API.Services
{
    public class Services
    {

        //dbcontext = new dbContext<Login>();
        public void getLogin(string username, string password)
        {
            using (var connection = new SqliteConnection("https://sqliteonline.com/"))
            {
                connection.Open();
                connection.CreateCommand().ExecuteNonQuery();
                SqliteCommand command = connection.CreateCommand();
                command = new SqliteCommand("select username,password from Login", connection);

                command.ExecuteReader();
            }
        }

        public void PostProducts(string values)
        {
            using (var connection = new SqliteConnection())
            {

                connection.Open();
                connection.CreateCommand().ExecuteNonQuery();
                SqliteCommand command = connection.CreateCommand();
                command = new SqliteCommand(@"INSERT INTO PRoducts (Name,Description,Price,color,size,instock) VALUES (
  "",
  "",
  "",
  "",
  "",
  ""
)",connection); 


                //command.ExecuteNonQuery();
                command.Parameters.Add(command.ExecuteScalar());

            }
        }

        public void GetProducts()
        {
            using (var connection = new SqliteConnection("https://sqliteonline.com/"))
            {
                connection.Open();
                connection.CreateCommand().ExecuteNonQuery();
                SqliteCommand command = connection.CreateCommand();
                command = new SqliteCommand("select Name,Description,Price,color,size,instock from PRoducts", connection);

                command.ExecuteReader();
            }

        }
        public void UpDateProducts(string Name,string Description)
        {
            using (var connection = new SqliteConnection("https://sqliteonline.com/"))
            {
                connection.Open();
                connection.CreateCommand().ExecuteNonQuery();
                SqliteCommand command = connection.CreateCommand();
                command = new SqliteCommand("update table PRoducts set Name = "+Name+ " where Description = "+Description+" ", connection);

                command.ExecuteReader();
            }
        }
        public void DeleteProducts(string Name)
        {
            using (var connection = new SqliteConnection("https://sqliteonline.com/"))
            {
                connection.Open();
                connection.CreateCommand().ExecuteNonQuery();
                SqliteCommand command = connection.CreateCommand();
                command = new SqliteCommand("delete table PRoducts  where Description = " + Name + " ", connection);

                command.ExecuteReader();
            }
        }
    }
}
